package edu.psu.ist.hcdd340.finalproject;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class ForumActivity extends AppCompatActivity {
    private final ForumPostData[] CAMPUS_LIST = {
            new ForumPostData("CoolCat82", R.drawable.beaver, "Sick Hike in the penn state area, i saw an awesome bird"),
            new ForumPostData("FortniteFanatic", R.drawable.gingerdude, "DEER SIGHTING THREAD, POST THE COOLEST DEER YOU FOUND"),
            new ForumPostData("SeanDermett_", R.drawable.stripes, "What do you guys think about hiking solo?"),
            new ForumPostData("AndrewEvert11", R.drawable.beaver, "What snacks should I bring with me to hike mount nittany"),
            new ForumPostData("cooldude219", R.drawable.beaver, "Looking for a fortnite themed hike"),
            new ForumPostData("MisterEvil", R.drawable.beaver, "I am looking to do some evil"),
            new ForumPostData("Josh", R.drawable.beaver, "I found some water like 70 yards from a road, should I drink it?"),
            new ForumPostData("Av4ageGamerBr0", R.drawable.beaver, "What are your favorite MREs for backpacking? I don't have one cuz I dont go out"),
            new ForumPostData("HikingHenry12", R.drawable.beaver, "Why are synthetic boots so popular anyway"),
            new ForumPostData("HikingHenry13", R.drawable.beaver, "How many skips have you gotten while skipping rocks"),
            new ForumPostData("itzonlymech6650", R.drawable.beaver, "Who else just sleeps in their sleeping bag when they havent hiked in a while"),
            new ForumPostData("Ristwach", R.drawable.beaver, "Anyone ever been to Everest?"),
            new ForumPostData("samsanchex1670", R.drawable.beaver, "TarpChads make Tentcels seethe"),
            new ForumPostData("supercat2087", R.drawable.beaver, "Anyone else prefer hiking in the cold for some reason"),
            new ForumPostData("peanutbutterphillip", R.drawable.beaver, "Should I take a map and compass class or can I just learn it on youtube"),
            new ForumPostData("austinfiregaming9740", R.drawable.beaver, "Lets talk about backpacks"),
            new ForumPostData("JulioJones", R.drawable.beaver, "Taking my dog with me?"),
            new ForumPostData("AJBrownTheGOAT", R.drawable.beaver, "Anyone know any hikes in state college that would be fine for kids and fun for me"),
            new ForumPostData("LeFlopHater27", R.drawable.beaver, "I want to go HIKING"),
            new ForumPostData("Nash558", R.drawable.beaver, "Its starting to get cold, how do you guys adjust when ur hiking"),
            new ForumPostData("JohnSmith12", R.drawable.beaver, "What is the best store for hiking stuff ")
    };

    private RecyclerView mRecyclerView;
    private ForumListAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forum);

        mRecyclerView = findViewById(R.id.recycler_view_forumposts);
        mAdapter = new ForumListAdapter(this, CAMPUS_LIST);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
}
