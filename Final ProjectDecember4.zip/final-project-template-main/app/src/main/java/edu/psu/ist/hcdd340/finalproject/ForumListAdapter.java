package edu.psu.ist.hcdd340.finalproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

public class ForumListAdapter extends
        RecyclerView.Adapter<ForumListAdapter.ForumViewHolder> {
    private final ForumPostData[] mCampusList;
    private final LayoutInflater mInflater;

    public ForumListAdapter(Context context, ForumPostData[] mCampusList) {
        this.mCampusList = mCampusList;
        mInflater = LayoutInflater.from(context);

    }

    @NonNull
    @Override
    public ForumViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View mItemView = mInflater.inflate(R.layout.forum_list_item, parent, false);
        return new ForumViewHolder(mItemView, this);
    }

    @Override
    public void onBindViewHolder(@NonNull ForumViewHolder holder, int position) {
        ForumPostData forumPost = mCampusList[position];
        holder.forumPostImageView.setImageResource(forumPost.getProfileImage());
        holder.forumPostUsernameView.setText(forumPost.getPosterUsername());
        holder.forumPostTopicView.setText(forumPost.getForumTopic());
    }

    @Override
    public int getItemCount() {
        return mCampusList.length;
    }

    class ForumViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public final TextView forumPostUsernameView;
        public final ImageView forumPostImageView;
        public final TextView forumPostTopicView;
        final ForumListAdapter mAdapter;

        public ForumViewHolder(@NonNull View itemView, ForumListAdapter adapter) {
            super(itemView);
            forumPostUsernameView = itemView.findViewById(R.id.forum_post_username_id);
            forumPostImageView = itemView.findViewById(R.id.forum_post_image_id);
            forumPostTopicView = itemView.findViewById(R.id.forum_post_topic);
            this.mAdapter = adapter;

            forumPostUsernameView.setOnClickListener(this);
            forumPostImageView.setOnClickListener(this);
            forumPostTopicView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            // Get the position of the item that was clicked.
            int mPosition = getLayoutPosition();
            // Use that to access the affected item in mWordList.
            String campus = mCampusList[mPosition].getPosterUsername();
            Snackbar.make(forumPostUsernameView,
                    campus + " clicked!",
                    Snackbar.LENGTH_SHORT).show();

        }
    }
}



