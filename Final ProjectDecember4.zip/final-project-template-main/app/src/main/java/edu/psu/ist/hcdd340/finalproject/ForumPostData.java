package edu.psu.ist.hcdd340.finalproject;

class ForumPostData {
    final private String posterUsername;
    final private int profileImage;
    final private String forumTopic;

    public ForumPostData(String userName, int profileImage,
                         String topic) {
        this.posterUsername = userName;
        this.forumTopic = topic;
        this.profileImage = profileImage;
    }


    public String getPosterUsername() {
        return posterUsername;
    }

    public String getForumTopic() {
        return forumTopic;
    }

    public int getProfileImage() {
        return profileImage;
    }
}
