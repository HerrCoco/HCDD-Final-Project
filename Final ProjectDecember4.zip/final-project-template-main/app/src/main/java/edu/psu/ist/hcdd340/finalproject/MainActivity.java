package edu.psu.ist.hcdd340.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //change to forum list
        Button forumBtn = findViewById(R.id.forumButton);
        forumBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        Intent forumIntent = new Intent(this, ForumActivity.class);
        startActivity(forumIntent);
    }
}